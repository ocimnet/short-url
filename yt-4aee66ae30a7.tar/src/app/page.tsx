'use client'

import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Maximize, Minimize, Play, SquarePen, X, Youtube } from 'lucide-react'

const YT_ID_RE = /^[a-zA-Z0-9_-]{11}$/

function extractVideoId(input: string): string | null {
  const trimmed = input.trim()
  if (!trimmed) return null
  if (YT_ID_RE.test(trimmed)) return trimmed

  try {
    const url = new URL(trimmed.startsWith('http') ? trimmed : `https://${trimmed}`)
    const host = url.hostname.replace(/^www\./, '')

    if (host === 'youtu.be') {
      const id = url.pathname.split('/')[1] ?? ''
      return YT_ID_RE.test(id) ? id : null
    }

    if (host.endsWith('youtube.com') || host.endsWith('youtube-nocookie.com')) {
      const v = url.searchParams.get('v')
      if (v && YT_ID_RE.test(v)) return v

      const m = url.pathname.match(/\/(embed|shorts|live|v)\/([a-zA-Z0-9_-]{11})/)
      if (m) return m[2]
    }
  } catch {
    return null
  }

  return null
}

const noopSubscribe = () => () => {}

function useHydrated() {
  return useSyncExternalStore(
    noopSubscribe,
    () => true,
    () => false,
  )
}

export default function Home() {
  const hydrated = useHydrated()

  // null = belum ada pilihan pengguna (ikut URL), '' = ditutup manual, 'ID' = video terpilih
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [inputValue, setInputValue] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [changing, setChanging] = useState(false)
  const [revealed, setRevealed] = useState(true)
  const [isFullscreen, setIsFullscreen] = useState(false)

  const hideTimer = useRef<number | null>(null)
  const changeInputRef = useRef<HTMLInputElement>(null)

  // ID video dari URL (?v= atau ?video=), hanya dibaca setelah hydration
  const urlId = useMemo(() => {
    if (!hydrated || typeof window === 'undefined') return null
    const params = new URLSearchParams(window.location.search)
    return extractVideoId(params.get('v') ?? params.get('video') ?? '')
  }, [hydrated])

  const videoId = selectedId !== null ? selectedId || null : urlId
  const controlsVisible = !videoId || changing || revealed

  const updateUrl = useCallback((id: string | null) => {
    const url = new URL(window.location.href)
    if (id) {
      url.searchParams.set('v', id)
    } else {
      url.searchParams.delete('v')
      url.searchParams.delete('video')
    }
    window.history.replaceState(null, '', url.toString())
  }, [])

  const startWatching = useCallback(
    (raw: string) => {
      const id = extractVideoId(raw)
      if (!id) {
        setError('Link atau ID tidak valid. Contoh: https://www.youtube.com/watch?v=dQw4w9WgXcQ')
        return
      }
      setError(null)
      setSelectedId(id)
      setChanging(false)
      setRevealed(true)
      setInputValue(`https://www.youtube.com/watch?v=${id}`)
      updateUrl(id)
    },
    [updateUrl],
  )

  const stopWatching = useCallback(() => {
    setSelectedId('')
    setChanging(false)
    setError(null)
    setInputValue('')
    updateUrl(null)
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {})
    }
  }, [updateUrl])

  const toggleFullscreen = useCallback(() => {
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {})
    } else {
      document.documentElement.requestFullscreen().catch(() => {})
    }
  }, [])

  const openChangeOverlay = useCallback(() => {
    setChanging(true)
    setRevealed(true)
    setInputValue(videoId ? `https://www.youtube.com/watch?v=${videoId}` : '')
    window.setTimeout(() => changeInputRef.current?.focus(), 0)
  }, [videoId])

  // Auto-hide kontrol saat video aktif: hanya lewat timer & event listener (tanpa setState sinkron)
  useEffect(() => {
    if (!videoId || changing) return

    const scheduleHide = () => {
      if (hideTimer.current) window.clearTimeout(hideTimer.current)
      hideTimer.current = window.setTimeout(() => setRevealed(false), 2600)
    }

    const reveal = () => {
      setRevealed(true)
      scheduleHide()
    }

    scheduleHide()
    window.addEventListener('mousemove', reveal)
    window.addEventListener('touchstart', reveal, { passive: true })

    return () => {
      if (hideTimer.current) window.clearTimeout(hideTimer.current)
      window.removeEventListener('mousemove', reveal)
      window.removeEventListener('touchstart', reveal)
    }
  }, [videoId, changing])

  // Escape menutup overlay "ganti video"
  useEffect(() => {
    if (!changing) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setChanging(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [changing])

  // Sinkronisasi status layar penuh browser
  useEffect(() => {
    const onFsChange = () => setIsFullscreen(Boolean(document.fullscreenElement))
    document.addEventListener('fullscreenchange', onFsChange)
    return () => document.removeEventListener('fullscreenchange', onFsChange)
  }, [])

  if (!hydrated) {
    return <div className="min-h-screen bg-zinc-950" aria-hidden="true" />
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      {videoId ? (
        <main className="fixed inset-0 bg-black">
          <iframe
            key={videoId}
            src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1&playsinline=1`}
            title="Pemutar video YouTube layar penuh"
            className="absolute inset-0 h-full w-full border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
          />

          {/* Bilah kontrol yang muncul-hilang otomatis */}
          <div
            className={`absolute right-3 top-3 z-10 flex items-center gap-1 rounded-full border border-white/10 bg-black/60 p-1.5 backdrop-blur-md transition-opacity duration-300 sm:right-4 sm:top-4 ${
              controlsVisible ? 'opacity-100' : 'pointer-events-none opacity-0'
            }`}
          >
            <Button
              variant="ghost"
              size="icon"
              onClick={openChangeOverlay}
              aria-label="Ganti video"
              title="Ganti video"
              className="h-11 w-11 rounded-full text-zinc-200 hover:bg-white/10 hover:text-white"
            >
              <SquarePen className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleFullscreen}
              aria-label={isFullscreen ? 'Keluar dari layar penuh' : 'Masuk ke layar penuh'}
              title={isFullscreen ? 'Keluar dari layar penuh' : 'Layar penuh'}
              className="h-11 w-11 rounded-full text-zinc-200 hover:bg-white/10 hover:text-white"
            >
              {isFullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={stopWatching}
              aria-label="Tutup video"
              title="Tutup video"
              className="h-11 w-11 rounded-full text-zinc-200 hover:bg-white/10 hover:text-white"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Overlay ganti video */}
          {changing && (
            <div
              className="absolute inset-0 z-20 flex items-start justify-center bg-black/70 p-4 pt-24 backdrop-blur-sm sm:pt-32"
              onClick={() => setChanging(false)}
            >
              <form
                className="w-full max-w-xl rounded-2xl border border-white/10 bg-zinc-900/95 p-4 shadow-2xl sm:p-6"
                onClick={(e) => e.stopPropagation()}
                onSubmit={(e) => {
                  e.preventDefault()
                  startWatching(inputValue)
                }}
              >
                <h2 className="text-base font-semibold sm:text-lg">Ganti video</h2>
                <p className="mt-1 text-sm text-zinc-400">
                  Tempel link atau ID video YouTube yang baru.
                </p>
                <div className="mt-4 flex flex-col gap-3 sm:flex-row">
                  <Input
                    ref={changeInputRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="https://www.youtube.com/watch?v=..."
                    inputMode="url"
                    autoComplete="off"
                    aria-label="Link atau ID video YouTube"
                    className="h-11 flex-1 border-white/10 bg-zinc-950 text-zinc-100 placeholder:text-zinc-500"
                  />
                  <Button type="submit" className="h-11 bg-red-600 px-6 text-white hover:bg-red-500">
                    Putar
                  </Button>
                </div>
                {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
              </form>
            </div>
          )}
        </main>
      ) : (
        <main className="flex min-h-screen flex-col items-center justify-center px-4 py-10">
          <div className="w-full max-w-md">
            <div className="flex flex-col items-center text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-red-600 shadow-lg shadow-red-600/20">
                <Youtube className="h-9 w-9 text-white" aria-hidden="true" />
              </div>
              <h1 className="mt-5 text-2xl font-bold tracking-tight sm:text-3xl">
                YouTube Full Screen
              </h1>
              <p className="mt-2 text-sm leading-relaxed text-zinc-400 sm:text-base">
                Tempel link atau ID video YouTube, lalu tonton langsung dalam mode layar penuh.
              </p>
            </div>

            <form
              className="mt-8"
              onSubmit={(e) => {
                e.preventDefault()
                startWatching(inputValue)
              }}
            >
              <label htmlFor="yt-input" className="sr-only">
                Link atau ID video YouTube
              </label>
              <Input
                id="yt-input"
                autoFocus
                value={inputValue}
                onChange={(e) => {
                  setInputValue(e.target.value)
                  if (error) setError(null)
                }}
                placeholder="https://www.youtube.com/watch?v=..."
                inputMode="url"
                autoComplete="off"
                className="h-12 border-white/10 bg-zinc-900 text-base text-zinc-100 placeholder:text-zinc-500 focus-visible:ring-red-600"
              />
              {error && (
                <p className="mt-3 text-sm text-red-400" role="alert">
                  {error}
                </p>
              )}
              <Button
                type="submit"
                className="mt-4 h-12 w-full bg-red-600 text-base font-semibold text-white hover:bg-red-500"
              >
                <Play className="mr-2 h-5 w-5 fill-current" aria-hidden="true" />
                Tonton Layar Penuh
              </Button>
            </form>

            <p className="mt-6 text-center text-xs leading-relaxed text-zinc-500">
              Mendukung link youtu.be, /shorts/, /embed/, atau ID video 11 karakter.
              <br />
              Bisa juga buka langsung: <span className="text-zinc-400">/?v=ID_VIDEO</span>
            </p>
          </div>
        </main>
      )}
    </div>
  )
}
