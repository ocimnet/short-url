import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "YouTube Full Screen",
  description:
    "Website minimalis untuk menonton video YouTube dalam mode layar penuh. Tempel link atau ID video, langsung putar.",
  keywords: ["YouTube", "fullscreen player", "pemutar video", "layar penuh", "iframe"],
  authors: [{ name: "Z.ai Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "YouTube Full Screen",
    description: "Tonton video YouTube dalam mode layar penuh",
    siteName: "YouTube Full Screen",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "YouTube Full Screen",
    description: "Tonton video YouTube dalam mode layar penuh",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
